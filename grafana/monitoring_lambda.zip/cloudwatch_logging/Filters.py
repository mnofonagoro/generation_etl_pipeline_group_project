COST_EFFECTIVE = {"name", "args", "filename", "module", "thread", "threadName", "processName", "process"}
LOGSTASH = {"type"}
NONE = {}
